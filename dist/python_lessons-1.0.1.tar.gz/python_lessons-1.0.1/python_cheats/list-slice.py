# list[<start>:<end>:<step>]

A = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(A[6:2:-1])  # [7, 6, 5, 4]
print(A[len(A)::-1])  # [10, 9, 8, 7, 6, 5, 4, 3, 2, 1] - reversing

C = [1] * 10
print(C)

# check if module is __main__
import math
import modules.module_one
if __name__ == '__main__':
    pass
    # from modules import module_one
    # from modules.module_one import *
    # print(modules.module_one.print_sum(1, 2))
    # print(module_one.print_sum(4, 9))
    # print(print_sum(10, 20))

# information about modules
help('math')

print(math.log2(90))

# create packages

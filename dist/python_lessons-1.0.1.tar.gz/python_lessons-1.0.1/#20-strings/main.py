# strings concat
print('Hello '+'Python')


# format strings
hello = 'Hello'
python = 'Python'

y = f"{hello} {python}"
print(y)


# practice
print('\n')
my_name = 'Taras'
my_hobby = 'Welding'
time = 8

info = my_name+" likes "+my_hobby+" at "+str(time)+" o'clock"
print(info)

info = f"{my_name} likes {my_hobby} at {time} o'clock"
print(info)

my_list = [1, 2, 3]
my_dict = {'a': 1, 'b2': 2}

del my_list[2]
del my_dict['a']

print(my_list)
print(my_dict)

# practice

# JSON - Javascript Object Notation
# types - string, number, JSON object, boolean, array, null

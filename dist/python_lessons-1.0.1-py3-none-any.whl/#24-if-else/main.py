if 10-3:
    print("True")
else:
    print('False')


if 10:
    ...
elif 0:
    ...
elif 8:
    ...
else:
    ...

# ternal operator
d = 9 + 7 if True else 100 - 90
print(d)

r1 = range(-6, 10, 3)
print(list(r1))


# practice
print('\n')
my_range = range(10)
for i in my_range:
    print(i)

print(my_range.start)

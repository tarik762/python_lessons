long_str = """
This is a 
very long 
string
"""
print(long_str)
print(type(long_str))


# builtin functions
my_comment = "This is my short comment"
print(len(my_comment))
print(my_comment.replace('short', 'long'))
print(my_comment.count('is'))

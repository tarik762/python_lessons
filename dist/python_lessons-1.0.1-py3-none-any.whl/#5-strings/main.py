# str - immutable object
my_name = 'Taras'
print(my_name)

greeteng = "Hello from Python"
print(greeteng)

print(type(greeteng))

print(id(greeteng))

long_str = """
Inform message
"""
print(long_str)


# builtin functions
str2 = "taras is a boy"
print(len(str2))
print(str2[1:4])
print(str2.count('a'))
# index(), upper(), replace()

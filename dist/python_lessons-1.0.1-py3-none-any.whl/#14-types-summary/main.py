#            changeable        has order          duplicates
list()         # V                 V                  V
tuple()        # X                 V                  V
set()          # V                 X                  X
range(1)       # X                 V                  X
dict()         # V                 X                  X
str()          # X                 V                  V

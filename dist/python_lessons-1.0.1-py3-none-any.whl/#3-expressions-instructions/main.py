# expressions
import datetime
10 + 5
print(10 + 5)
# print(input())


# statements
my_name = 'Taras'
if my_name:
    print('hello')

print(datetime.MAXYEAR)
print(dir(datetime))


def my_func(a, b):
    c = a + b + 0x1
    return c


print(my_func(45, 65))

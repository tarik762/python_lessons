import time
print(100 > 10)
print('a' > 'q')
print([1, 2] == [2, 3])
print(bool(0))


# practice
db_is_available = True
print(type(db_is_available))
if db_is_available:
    print(9)

db_is_available = not db_is_available
print(db_is_available)

_NAME = 'Taras'


def print_sum(a, b):
    return a + b

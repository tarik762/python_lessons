print(id(10))
print(id(11))

my_num = 5
print(id(my_num))
my_num = "tggg"
print(id(my_num))
